export const todos = [
    {
        title: "This is some title",
        desc: " This is some description",
        author: 'ibrar',
        status:  'completed'
    },
    {
       title: "This is another title",
       desc: " This is another description",
       author: 'ibrar',
       status:  'pending'
   },
   {
    title: "This is third title",
    desc: " This is third description",
    author: 'ibrar',
    status:  'pending'
}
]