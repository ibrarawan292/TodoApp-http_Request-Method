
import React from 'react'
import { useParams } from 'react-router-dom'







const Details = ({todo}) => {

  const {title} = useParams()

  const todos = todo.find(todo => todo.title === title)
  
  return (
    <div className='container'>
      <h1>{todos.title}</h1>
      <p>{todos.desc}</p>
      <p>{todos.author}</p>
      <p className={`badge rounded-pill bg-${todo.status === 'completed'? 'success':'danger'}`}>{todos.status}</p>
     
   
    </div>
  )
}

export default Details