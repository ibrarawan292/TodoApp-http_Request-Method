import React from 'react'
import { Link } from 'react-router-dom'

const Todolist = ({ listItems }) => {

    return (
        listItems.length === 0 ? <h3 style={{ background: 'grey', textAlign: 'center', width: '50%', margin: '0 auto' }}>Data not found</h3> : listItems.map((newItem) => {
            return (
                <div key={"listItems" + newItem.title + newItem.desc} className="container  mx-auto mb-2 p-3 " style={{ background: 'grey', textAlign: 'center', width: '50%', margin: '0 auto' }}>
                    <Link to={`/tododetail/${newItem.title}`}><h1>{newItem.title}</h1></Link>
                    <p>{newItem.desc}</p>


                </div>
            )
        })
    )
}

export default Todolist