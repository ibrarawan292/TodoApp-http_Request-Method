import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";




const Header = ({ todo }) => {

    const [categories, setCategories] = useState([])

    useEffect(() => {
        // fetch('https://fakestoreapi.com/products/categories')
        //     .then(res => res.json())
        //     .then(data => setCategories(data))

      const category =  axios.get('https://fakestoreapi.com/products/categories')
      category.then((res) => setCategories(res.data))

    }, []) 


    return (
        <div className="container">
            <nav className="navbar navbar-expand-lg ">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/">Navbar</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav " >
                            <li className="nav-item">
                                <Link className="nav-link " aria-current="page" to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/">Features</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/">Pricing</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link " to="/products" >Products</Link>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Categories
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                                   <li><Link to="/products/category/jewelery">Jewelery</Link></li>
                                   <li><Link to="/products/category/electronics">electronics</Link></li>
                                   <li><Link to="/products/category/mensclothing">men's clothing</Link></li>
                                   <li><Link to="/products/category/womensclothing">women's clothing</Link></li>
                                </ul>
                            </li>
                        </ul>
                        <h1>Total listItems: {todo.length}</h1>
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Header
