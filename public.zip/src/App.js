
import './App.css';
import Header from './Components/Header';
import Form from './Components/Form';
import { BrowserRouter, Routes, Route, } from "react-router-dom";
import Details from './Components/Details';
import { useEffect, useState } from 'react';
import Products from './Pages/Products';
import Jewelery from './Pages/Jewelery';
import ProductDetail from './Pages/ProductDetail';











function App() {

  const [todo, setTodo] = useState([])


    useEffect(() => {
        setTodo(localStorage.getItem('todo')? JSON.parse(localStorage.getItem('todo')): [])

    }, [])

  localStorage.setItem('todo', JSON.stringify(todo))


   

  return (

    <div className="App">

      <BrowserRouter>
        <Header todo={todo} />
        <Routes>
          <Route path='/tododetail/:title' element={<Details todo={todo} />} />
          <Route path='/' element={<Form todo={todo} setTodo={setTodo} />} />
          <Route path='/products' element ={<Products/>} />
          <Route path='/products/category/jewelery' element ={<Jewelery/>} />
          <Route path='/productdetail/:paramId' element={<ProductDetail/>} />
         
        </Routes>

      </BrowserRouter>

    </div>

  );
}

export default App;
