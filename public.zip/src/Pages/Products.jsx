import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import StarsRating from 'stars-rating'

const Products = () => {

  const [products, setProducts] = useState([])

  const [loading, setLoading] = useState(false)

  async function getProducts() {
    try {
      setLoading(true);
      const prods = await axios.get(`https://fakestoreapi.com/products/`);
      setLoading(false);
      setProducts(prods.data)
    } catch (error) {
      console.log(error)
        
    }

  }
 

  async function createProduct() {
    try {
      
    } catch (error) {
      console.log(error)
        
    }

  }
  async function updateProduct() {
    try {
      
    } catch (error) {
      console.log(error)
        
    }

  }
  async function deleteProduct() {
    try {
      
    } catch (error) {
      console.log(error)
        
    }

  }


  useEffect(() => {
    getProducts()
  }, [])

  return (
    <div className='row '>
     
      {
        loading? <h1>Loading...</h1>:products.map(product => {
          return (
            <div className="col-md-4 ">
                <div className="card">
                  <img style={{ width: "200px" }} src={product.image} className="card-img-top" alt="..." />
                  <div className="card-body">
                    <h5 className="card-title">{product.title}</h5>
                    <p className="card-text">{product.description}</p>
                    <p>Price: <strong> ${product.price}</strong></p>
                    <StarsRating
                      count={product.rating.rate}
                      size={24}
                      color2={'#ffd700'} />
                    <span>({product.rating.count})</span>

                    <Link to={`/productdetail/${product.id}`}>Detail</Link>
                  </div>
                </div>
            </div>

          )
        })
      }
    </div>
  )
}

export default Products