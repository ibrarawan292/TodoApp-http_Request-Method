import React,{useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import StarsRating from 'stars-rating'

const Jewelery = () => {
    const [jewelery, setJewelery] = useState([])



  useEffect(() => {
    fetch('https://fakestoreapi.com/products/category/jewelery')
      .then(res => res.json())
      .then(data => setJewelery(data))

  }, [])

  return (
    <div className='row m-0'>
      {
        jewelery.map(jewelery => {
          return (
            <div className="col-md-4 ">
              <Link to={`/prducts`}>
                <div class="card">
                  <img style={{ width: "200px" }} src={jewelery.image} class="card-img-top" alt="..." />
                  <div class="card-body">
                    <h5 class="card-title">{jewelery.title}</h5>
                    <p class="card-text">{jewelery.description}</p>
                    <p>Price: <strong> ${jewelery.price}</strong></p>
                    <StarsRating
                      count={jewelery.rating.rate}
                      size={24}
                      color2={'#ffd700'} />
                    <span>({jewelery.rating.count})</span>
                  </div>
                </div></Link>
            </div>

          )
        })
      }
    </div>
  )
}

export default Jewelery